Blockly.Msg.ultrasonic_TEXT_TITLE   = "ultrasonic TITLE";
Blockly.Msg.ultrasonic_TEXT_TOOLTIP = "ultrasonic TOOLTIP";
Blockly.Msg.ultrasonic_TEXT_HELPURL = "ultrasonic HELPURL";
